#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <string>
#include <stdlib.h>

using namespace std;

enum Suit { Diamonds, Hearts, Clubs, Spades };

std::string getTypeStr(Suit type)
{
    switch(type)
    {
        case Diamonds:
            return "diamonds";
        case Hearts:
            return "hearts";
    }

    return "";
}

void readFile(std::string path)
{
    std::ifstream infile(path.c_str());

    int i = 0;
    std::string line;

    std::string segment;
    std::vector<std::string> seglist;
    std::vector<float> values;

    while (std::getline(infile, line))
    {
        seglist.clear();
        std::stringstream s;
        s << line;
        while(std::getline(s, segment, ','))
        {
           seglist.push_back(segment);
           //cout << segment << endl;
        }

        if (seglist.size() != 3)
        {
            continue;
        }

        stringstream os;
        os << seglist[1] << "." << seglist[2];

        //value = strtof(os.str().c_str(), &pEnd);
        float value = atof(os.str().c_str());
        values.push_back(value);

        cout << seglist[0] << ": " << value << endl;
        //cout << ++i << ": " << line << endl;

        //std::istringstream iss(line);
        //cout << iss.str() << endl;
        //int a, b;
        //if (!(iss >> a >> b)) { break; } // error

        // process pair (a,b)
    }

    infile.close();
}

int main()
{
    /*int i = 1;
    int j = ++i;

    cout << i << " " << j << endl;

    i = 1;
    j = i++;

    cout << i << " " << j << endl;*/

    Suit suit = Hearts;

    cout << suit << endl;
    cout << getTypeStr(suit) << endl;

    int idNum = 3;
    ostringstream os;
    os << getTypeStr(suit) << "_" << idNum;
    cout << os.str() << endl;


    std::stringstream test("awgn0_69");
    std::string segment;
    std::vector<std::string> seglist;

    while(std::getline(test, segment, '_'))
    {
       seglist.push_back(segment);
       //cout << segment << endl;
    }

    idNum = atoi(seglist[0].c_str());
    cout << idNum << endl;
    idNum = atoi(seglist[1].c_str());
    cout << idNum << endl;

    readFile("C:\\Temp\\Github\\SandboxCpp\\bin\\Debug\\result_data_VolDown.txt");

    return 0;
}
